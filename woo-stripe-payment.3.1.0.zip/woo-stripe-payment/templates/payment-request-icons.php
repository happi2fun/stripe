<?php
/**
 * @version 3.0.0
 */
?>
<div class="wc-stripe-paymentRequest-icons-container">
	<img class="wc-stripe-paymentRequest-icon"
		src="<?php echo wc_stripe()->assets_url('img/chrome.svg')?>" /> <img
		class="wc-stripe-paymentRequest-icon"
		src="<?php echo wc_stripe()->assets_url('img/edge.svg')?>" />
</div>