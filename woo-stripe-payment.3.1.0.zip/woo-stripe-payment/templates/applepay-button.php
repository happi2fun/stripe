<?php
/**
 * @version 3.0.0
 * @package Stripe/Templates
 */
?>
<button class="apple-pay-button <?php echo $style?>" style="<?php echo '-apple-pay-button-type:' . apply_filters('wc_stripe_applepay_button_type', $type)?>"></button>